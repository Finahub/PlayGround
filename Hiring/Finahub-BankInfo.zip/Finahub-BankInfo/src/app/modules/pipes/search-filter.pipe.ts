import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

  transform(value: any[], args: string): any[] {
    let searchFilter: string = args ? args.toLocaleLowerCase() : null;
    return searchFilter ? value.filter(employee =>
      employee.name.toLocaleLowerCase().startsWith(searchFilter) != false) : value;
  }
}
