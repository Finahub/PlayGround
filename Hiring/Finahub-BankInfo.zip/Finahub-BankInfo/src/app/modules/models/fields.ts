export class Fields {
    bankName: string;
    crdtCardCount: number;
    dbtCardCount: number;
  }