import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BankInfoModule } from './modules/bank-info.module';
import { BankInfoComponent } from './modules/bank-info/bank-info.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: '/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'dashboard',
    component: BankInfoComponent
  },
  // {path: '**', redirectTo:'/dashboard'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
