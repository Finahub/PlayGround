import { NgModule } from '@angular/core';
import { SearchFilterPipe } from '../modules/pipes/search-filter.pipe';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCheckboxModule } from '@angular/material/checkbox';


@NgModule({
  declarations: [SearchFilterPipe],
  imports: [
    FormsModule, ReactiveFormsModule, BrowserAnimationsModule,
    MatButtonModule, BrowserModule,MatInputModule,MatTableModule,MatPaginatorModule,MatSortModule,MatProgressSpinnerModule,MatFormFieldModule,MatCheckboxModule
  ],
  exports: [
    FormsModule, ReactiveFormsModule, BrowserAnimationsModule,
    MatButtonModule, BrowserModule,MatInputModule,MatTableModule,MatPaginatorModule,MatSortModule,MatProgressSpinnerModule,MatFormFieldModule,MatCheckboxModule
  ]

})
export class SharedModule { }
