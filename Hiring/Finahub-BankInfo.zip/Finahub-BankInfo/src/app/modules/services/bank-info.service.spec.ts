import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BankInfoService } from './bank-info.service';

describe('BankInfoService', () => {
  let service: BankInfoService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule],
      providers:[BankInfoService]
    });
    service = TestBed.inject(BankInfoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
