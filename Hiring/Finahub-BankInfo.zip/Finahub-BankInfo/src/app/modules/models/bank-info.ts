export interface BankInfo {
    bankName: string;
    crdtCardCount: number;
    dbtCardCount: number;
  }