export const APIConst = {
    FINAHUB: '/finahub',
    GET_BANK_INFO: '/getBankInfo',
    POST_BANK_INFO: '/saveBankInfo'
};