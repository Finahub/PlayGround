import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { BankInfoRoutingModule } from './bank-info-routing.module';
import { SharedModule } from '../shared/shared.module';
import { ToastrModule } from 'ngx-toastr';
import { BankInfoService } from './services/bank-info.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { BankInfoComponent } from './bank-info/bank-info.component';



@NgModule({
  declarations: [BankInfoComponent,DashboardComponent],
  imports: [
    CommonModule,HttpClientModule,
    BankInfoRoutingModule,SharedModule, ToastrModule.forRoot()
  ],
  providers: [BankInfoService]
})
export class BankInfoModule { }
