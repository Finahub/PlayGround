import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { APIConst } from '../constants/bank-info-constants';
import { BankInfo } from '../models/bank-info';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankInfoService {

  constructor(private httpClient: HttpClient) { }

  /**
   * @description To get the Bank Info
   */
  getBankInfo(): Observable<any[]> {
    return this.httpClient.get<any[]>(`${environment.baseUrl}${APIConst.FINAHUB}${APIConst.GET_BANK_INFO}`);
  }

  /**
   * @description To save Bank Info
   * @param param: any - Request parameter that required to pass to API
   */
  saveBankInfo(body): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      })
    };
    console.log(body);
    return this.httpClient.post(`${environment.baseUrl}${APIConst.FINAHUB}${APIConst.POST_BANK_INFO}`, body, httpOptions);
  }
  
}
