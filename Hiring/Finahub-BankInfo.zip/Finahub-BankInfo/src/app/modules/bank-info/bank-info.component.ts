import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { BankInfoModule } from '../bank-info.module';
import { MatPaginator } from '@angular/material/paginator';
import { BankInfoService } from '../services/bank-info.service';
import { ToastrService } from 'ngx-toastr';
import { Fields } from '../models/fields';
import { MatSort } from '@angular/material/sort';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
  selector: 'app-bank-info',
  templateUrl: './bank-info.component.html',
  styleUrls: ['./bank-info.component.css']
})
export class BankInfoComponent implements OnInit {

  displayedColumns = ["select", "seqNo", "bankName", "crdtCardCount", "dbtCardCount"];
  dataSource = new MatTableDataSource<Fields>();
  data: any[] = [];
  tableData: Fields[];
  tempData: any[] = [];
  showTable = false;
  isLoading = true;

  selection = new SelectionModel<Fields>(true, []);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;


  constructor(private bankService: BankInfoService, private tostr: ToastrService) { }

  ngOnInit(): void {

  }

  applyFilter(filterValue: string) {
    console.log(filterValue);
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  getBankInfo() {
    this.showTable = true;
    this.bankService.getBankInfo().subscribe(res => {
      if (res['status'] == 200 && res) {
        this.data = res['data']['records'];
        this.data.map((elm) => {
          this.tempData.push({ bankName: elm.fields['Bank'], crdtCardCount: elm.fields['Credit Card Count'], dbtCardCount: elm.fields['Debit Card Count'] });
          this.data.push(this.tempData);
        });
        this.dataSource = new MatTableDataSource<Fields>(this.tempData);
        this.isLoading = false;
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      } else {
        this.tostr.error("Data Fetching Failed. Please Refresh The Page....!!!");
      }
    });
  }

  hideBankInfo() {
    this.showTable = false;
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  saveBankInfo() {
    this.tableData = this.selection.selected;
    if (this.tableData.length > 0) {
      this.bankService.saveBankInfo(this.tableData).subscribe(res => {
        if (res['status'] == 200) {
          this.tostr.success("Data Saved Successfully.......!!!");
          this.selection.clear();
        } else {
          this.tostr.error("Data Not Saved. Please Try Again...!!!");
        }
      });
    } else {
      this.tostr.error("Please Select Any Data To Save....!!!");
    }
  }

}
